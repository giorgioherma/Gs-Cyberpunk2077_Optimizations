module GRedRuntime

public class StateCache extends IScriptable {
  private let m_game: GameInstance;
  private let m_player: wref<PlayerPuppet>;
  private let m_playerSystem: wref<PlayerSystem>;
  private let m_questsSystem: wref<QuestsSystem>;
  private let m_statsSystem: wref<StatsSystem>;
  private let m_delaySystem: wref<DelaySystem>;
  private let m_transactionSystem: wref<TransactionSystem>;
  private let m_blackboardSystem: wref<BlackboardSystem>;
  private let m_scriptableSystems: wref<ScriptableSystemsContainer>;
  private let m_timeSystem: wref<TimeSystem>;
  private let m_uiSystem: wref<UISystem>;
  private let m_statPoolsSystem: wref<StatPoolsSystem>;
  private let m_targetingSystem: wref<TargetingSystem>;
  private let m_marketSystem: wref<MarketSystem>;
  private let m_systemRequestsHandler: wref<inkISystemRequestsHandler>;
  private let m_preventionSystem: wref<PreventionSystem>;
  private let m_diagnostics: wref<Diagnostics>;

  public func Initialize(game: GameInstance, diagnostics: ref<Diagnostics>) -> Void {
    this.m_game = game;
    this.m_diagnostics = diagnostics;
  }

  public func Shutdown() -> Void {
    this.m_player = null;
    this.m_playerSystem = null;
    this.m_questsSystem = null;
    this.m_statsSystem = null;
    this.m_delaySystem = null;
    this.m_transactionSystem = null;
    this.m_blackboardSystem = null;
    this.m_scriptableSystems = null;
    this.m_timeSystem = null;
    this.m_uiSystem = null;
    this.m_statPoolsSystem = null;
    this.m_targetingSystem = null;
    this.m_marketSystem = null;
    this.m_systemRequestsHandler = null;
    this.m_preventionSystem = null;
  }

  public func GetGame() -> GameInstance {
    return this.m_game;
  }

  public func SetPlayer(player: wref<PlayerPuppet>) -> Void {
    this.m_player = player;
  }

  public func InvalidatePlayer() -> Void {
    this.m_player = null;
  }

  public func GetPlayer() -> wref<PlayerPuppet> {
    if IsDefined(this.m_player) {
      this.CacheHit();
      return this.m_player;
    }

    this.CacheMiss();
    let playerSystem = this.GetPlayerSystem();
    if IsDefined(playerSystem) {
      this.m_player = playerSystem.GetLocalPlayerMainGameObject() as PlayerPuppet;
    }
    return this.m_player;
  }

  public func GetPlayerSystem() -> wref<PlayerSystem> {
    if IsDefined(this.m_playerSystem) {
      this.CacheHit();
      return this.m_playerSystem;
    }

    this.CacheMiss();
    this.m_playerSystem = GameInstance.GetPlayerSystem(this.m_game);
    return this.m_playerSystem;
  }

  public func GetQuestsSystem() -> wref<QuestsSystem> {
    if IsDefined(this.m_questsSystem) {
      this.CacheHit();
      return this.m_questsSystem;
    }

    this.CacheMiss();
    this.m_questsSystem = GameInstance.GetQuestsSystem(this.m_game);
    return this.m_questsSystem;
  }

  public func GetStatsSystem() -> wref<StatsSystem> {
    if IsDefined(this.m_statsSystem) {
      this.CacheHit();
      return this.m_statsSystem;
    }

    this.CacheMiss();
    this.m_statsSystem = GameInstance.GetStatsSystem(this.m_game);
    return this.m_statsSystem;
  }

  public func GetDelaySystem() -> wref<DelaySystem> {
    if IsDefined(this.m_delaySystem) {
      this.CacheHit();
      return this.m_delaySystem;
    }

    this.CacheMiss();
    this.m_delaySystem = GameInstance.GetDelaySystem(this.m_game);
    return this.m_delaySystem;
  }

  public func GetTransactionSystem() -> wref<TransactionSystem> {
    if IsDefined(this.m_transactionSystem) {
      this.CacheHit();
      return this.m_transactionSystem;
    }

    this.CacheMiss();
    this.m_transactionSystem = GameInstance.GetTransactionSystem(this.m_game);
    return this.m_transactionSystem;
  }

  public func GetBlackboardSystem() -> wref<BlackboardSystem> {
    if IsDefined(this.m_blackboardSystem) {
      this.CacheHit();
      return this.m_blackboardSystem;
    }

    this.CacheMiss();
    this.m_blackboardSystem = GameInstance.GetBlackboardSystem(this.m_game);
    return this.m_blackboardSystem;
  }

  public func GetScriptableSystemsContainer() -> wref<ScriptableSystemsContainer> {
    if IsDefined(this.m_scriptableSystems) {
      this.CacheHit();
      return this.m_scriptableSystems;
    }

    this.CacheMiss();
    this.m_scriptableSystems = GameInstance.GetScriptableSystemsContainer(this.m_game);
    return this.m_scriptableSystems;
  }

  public func GetTimeSystem() -> wref<TimeSystem> {
    if IsDefined(this.m_timeSystem) {
      this.CacheHit();
      return this.m_timeSystem;
    }

    this.CacheMiss();
    this.m_timeSystem = GameInstance.GetTimeSystem(this.m_game);
    return this.m_timeSystem;
  }

  public func GetUISystem() -> wref<UISystem> {
    if IsDefined(this.m_uiSystem) {
      this.CacheHit();
      return this.m_uiSystem;
    }

    this.CacheMiss();
    this.m_uiSystem = GameInstance.GetUISystem(this.m_game);
    return this.m_uiSystem;
  }

  public func GetStatPoolsSystem() -> wref<StatPoolsSystem> {
    if IsDefined(this.m_statPoolsSystem) {
      this.CacheHit();
      return this.m_statPoolsSystem;
    }

    this.CacheMiss();
    this.m_statPoolsSystem = GameInstance.GetStatPoolsSystem(this.m_game);
    return this.m_statPoolsSystem;
  }

  public func GetTargetingSystem() -> wref<TargetingSystem> {
    if IsDefined(this.m_targetingSystem) {
      this.CacheHit();
      return this.m_targetingSystem;
    }

    this.CacheMiss();
    this.m_targetingSystem = GameInstance.GetTargetingSystem(this.m_game);
    return this.m_targetingSystem;
  }

  public func GetMarketSystem() -> wref<MarketSystem> {
    if IsDefined(this.m_marketSystem) {
      this.CacheHit();
      return this.m_marketSystem;
    }

    this.CacheMiss();
    this.m_marketSystem = MarketSystem.GetInstance(this.m_game);
    return this.m_marketSystem;
  }

  public func GetSystemRequestsHandler() -> wref<inkISystemRequestsHandler> {
    if IsDefined(this.m_systemRequestsHandler) {
      this.CacheHit();
      return this.m_systemRequestsHandler;
    }

    this.CacheMiss();
    this.m_systemRequestsHandler = GameInstance.GetSystemRequestsHandler();
    return this.m_systemRequestsHandler;
  }

  public func GetPreventionSystem() -> wref<PreventionSystem> {
    if IsDefined(this.m_preventionSystem) {
      this.CacheHit();
      return this.m_preventionSystem;
    }

    this.CacheMiss();
    let systems = this.GetScriptableSystemsContainer();
    if IsDefined(systems) {
      this.m_preventionSystem = systems.Get(n"PreventionSystem") as PreventionSystem;
    }
    return this.m_preventionSystem;
  }

  private func CacheHit() -> Void {
    if IsDefined(this.m_diagnostics) {
      this.m_diagnostics.StateCacheHit();
    }
  }

  private func CacheMiss() -> Void {
    if IsDefined(this.m_diagnostics) {
      this.m_diagnostics.StateCacheMiss();
    }
  }
}
